class NoSongSelectedError(Exception):
    pass
